// Game ke Ads manager ko asli AdMob se jodta hai (Capacitor AdMob plugin).
// Agar plugin nahi mila (browser me), game apne practice ads dikhata hai.
(function(){
 var C=window.ADS_CONFIG||{};
 function plug(){return window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.AdMob}
 // TESTING:true ho to screen par chhota message dikhta hai ki ad kyun nahi aaya (sirf test ke liye)
 function note(m){if(!C.TESTING&&!C.DEBUG)return;try{var d=document.createElement('div');d.textContent='AD: '+m;d.style.cssText='position:fixed;left:8px;right:8px;top:8px;z-index:99999;background:#000c;color:#fde047;font:12px sans-serif;padding:6px 8px;border-radius:8px;pointer-events:none';document.body.appendChild(d);setTimeout(function(){d.remove()},5000)}catch(e){}}
 function msg(e){return (e&&(e.message||e.code||JSON.stringify(e)))||'error'}
 var ready=false,initing=null;
 function init(){var A=plug();if(!A)return Promise.reject(new Error('AdMob plugin nahi mila'));if(ready)return Promise.resolve();if(initing)return initing;
  initing=A.initialize({initializeForTesting:!!C.TESTING,tagForChildDirectedTreatment:true,tagForUnderAgeOfConsent:true,maxAdContentRating:'G'}).then(function(){ready=true}).catch(function(e){initing=null;throw e});return initing}
 function once(A,ev,fn){var h=null,done=false;var r=A.addListener(ev,function(x){if(done)return;done=true;try{h&&h.remove&&h.remove()}catch(e){}fn(x)});Promise.resolve(r).then(function(x){h=x},function(){})}
 window.SpiderrunAds={
  showRewarded:function(cb){var A=plug();if(!A){cb(false);return}var got=false,fin=false;function end(ok){if(fin)return;fin=true;cb(ok)}
   init().then(function(){
    once(A,'onRewardedVideoAdReward',function(){got=true});
    once(A,'onRewardedVideoAdDismissed',function(){end(got)});
    once(A,'onRewardedVideoAdFailedToShow',function(e){note('rewarded show fail '+msg(e));end(false)});
    once(A,'onRewardedVideoAdFailedToLoad',function(e){note('rewarded load fail '+msg(e));end(false)});
    return A.prepareRewardVideoAd({adId:C.REWARDED,isTesting:!!C.TESTING}).then(function(){return A.showRewardVideoAd()});
   }).catch(function(e){note('rewarded '+msg(e));end(false)});
   setTimeout(function(){end(got)},120000)},
  showInterstitial:function(cb){var A=plug();if(!A){cb();return}var fin=false;function end(){if(fin)return;fin=true;cb()}
   init().then(function(){
    once(A,'interstitialAdDismissed',end);
    once(A,'interstitialAdFailedToShow',function(e){note('interstitial show fail '+msg(e));end()});
    once(A,'interstitialAdFailedToLoad',function(e){note('interstitial load fail '+msg(e));end()});
    return A.prepareInterstitial({adId:C.INTERSTITIAL,isTesting:!!C.TESTING}).then(function(){return A.showInterstitial()});
   }).catch(function(e){note('interstitial '+msg(e));end()});setTimeout(end,30000)},
  showBanner:function(){var A=plug();if(!A)return;init().then(function(){return A.showBanner({adId:C.BANNER,adSize:'ADAPTIVE_BANNER',position:'BOTTOM_CENTER',margin:0,isTesting:!!C.TESTING})}).catch(function(e){note('banner '+msg(e))})},
  hideBanner:function(){var A=plug();if(!A)return;try{A.removeBanner()}catch(e){}}
 };
})();
