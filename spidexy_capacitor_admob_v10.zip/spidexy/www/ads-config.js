// ===== AdMob IDs (S.K Studios / Spidexy) =====
// TESTING:true = Google ke TEST ads (sirf phone par test ke liye).
// TESTING:false = asli ads (Play Store release se pehle yahi karo). Asli ads par khud click mat karna.
window.ADS_CONFIG={
  TESTING:false,
  DEBUG:true,  // true = ad na aaye to screen par karan dikhta hai. Play Store release se pehle false karo.
  APP_ID:'ca-app-pub-1466673767880620~4351664074',
  INTERSTITIAL:'ca-app-pub-1466673767880620/9791819327',
  REWARDED:'ca-app-pub-1466673767880620/7994240663',
  BANNER:'ca-app-pub-1466673767880620/6493456730'
};
