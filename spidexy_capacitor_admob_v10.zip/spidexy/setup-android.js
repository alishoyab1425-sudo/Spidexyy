// `npx cap add android` ke BAAD ek baar chalao:  node setup-android.js
// 1) App ka icon lagata hai (resources/android-res se)  2) AdMob App ID manifest me daalta hai (www/ads-config.js se).
const fs=require('fs'),path=require('path');
const f='android/app/src/main/AndroidManifest.xml';
if(!fs.existsSync(f)){console.error('Pehle `npx cap add android` chalao');process.exit(1)}

// ---- ICON ----
const res='android/app/src/main/res', src='resources/android-res';
if(fs.existsSync(src)){
  fs.readdirSync(res).filter(d=>d.startsWith('mipmap')).forEach(d=>{
    fs.readdirSync(path.join(res,d)).filter(n=>n.startsWith('ic_launcher')).forEach(n=>fs.unlinkSync(path.join(res,d,n)));
  });
  fs.cpSync(src,res,{recursive:true});
  console.log('App icon laga diya');
}else console.log('resources/android-res nahi mila, default icon rahega');

// ---- ADMOB APP ID ----
const cfg=fs.readFileSync('www/ads-config.js','utf8');
const m=cfg.match(/APP_ID:\s*'([^']+)'/);
if(!m){console.error('APP_ID www/ads-config.js me nahi mila');process.exit(1)}
let x=fs.readFileSync(f,'utf8');
if(x.includes('com.google.android.gms.ads.APPLICATION_ID')){console.log('Pehle se jura hua hai, kuch nahi badla');process.exit(0)}
x=x.replace(/<application([^>]*)>/,(a)=>a+'\n        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="'+m[1]+'"/>');
fs.writeFileSync(f,x);console.log('AdMob App ID manifest me jod diya:',m[1]);
