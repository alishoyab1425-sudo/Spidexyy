# SABSE AASAN TAREEKA: Cloud build (laptop par kuch install nahi karna)

Android Studio install karne ki zarurat nahi. GitHub (free) par Google ke computer APK/AAB bana deta hai.

1. github.com par free account banao -> New repository -> naam `spidexy` -> **Private** -> Create.
2. Laptop ke browser me repo me "uploading an existing file" dabao. Is zip ko extract karke **andar ka saara kuch** (www, package.json, capacitor.config.json, setup-android.js aur **.github** folder) drag-drop karo -> Commit.
   (`.github` folder hidden ho sakta hai. Windows me File Explorer -> View -> Show -> Hidden items ON karo.)
3. Repo me **Actions** tab -> **Build APK** -> **Run workflow**. 5-10 minute baad wahi run kholo, neeche **Artifacts** me `Spidexy-APK` download karo. Zip khol ke `app-debug.apk` phone me bhejo aur install karo.
4. Phone par test ad dikhne chahiye. Rewarded ke baad "Double coins"/"Continue" chalna chahiye.

## Play Store ke liye AAB (cloud se)
1. Actions -> **Make Keystore (one time)** -> Run workflow, password likho (yaad rakho). Banne par Artifacts se `spidexy-keystore` download karo. **Is keystore aur password ko Drive + pen drive me rakho. Kho gaya to update nahi daal paoge.**
2. Repo -> Settings -> Secrets and variables -> Actions -> New repository secret:
   - `KEYSTORE_PASSWORD` = tumhara password
   - `KEYSTORE_BASE64` = zip me `keystore.b64.txt` ke andar ka poora text
3. `www/ads-config.js` me **TESTING:false** karo (Rewarded/Banner ke asli IDs dalne ke baad), commit karo.
4. Actions -> **Build AAB** -> Run workflow -> Artifacts se `Spidexy-AAB` download karo -> Play Console me upload.

Dhyan: ye cloud build maine likha hai par yahan chalake test nahi kiya. Pehli baar kuch error aaye to run ka laal (red) log screenshot bhej dena, theek kar dunga.

---
# (Purana tareeka: laptop par Android Studio)
# Spidexy - Laptop par AAB banane ki guide (S.K Studios)

Ye kaam laptop par EK BAAR karna hai (lagbhag 1-2 ghante). Phone se nahi hoga.

## Pehle ye install karo (free)
1. Node.js (nodejs.org se LTS version)
2. Android Studio (developer.android.com/studio se). Pehli baar khologe to wo Android SDK khud download karega.
3. Java 17 (Android Studio ke saath aa jata hai)

## AdMob ke IDs lo
1. admob.google.com par account banao -> Apps -> Add app -> Android -> naam "Spidexy".
2. Wahan se 1 **App ID** milega (`ca-app-pub-xxxxxxxx~yyyyyyyy`).
3. 3 Ad units banao: **Rewarded**, **Interstitial**, **Banner**. Har ek ka ID milega (`ca-app-pub-xxxxxxxx/zzzzzzzz`).
4. AdMob me App settings -> "Target audience / child-directed" bacchon wala option sahi chuno.
5. `www/ads-config.js` kholo, teeno ID wahan badlo. **TESTING:true** abhi rehne do.

## Commands (folder ke andar terminal kholkar)
```
npm install
npx cap add android
node setup-android.js
npx cap sync android
```
`setup-android.js` AdMob App ID (`www/ads-config.js` se) AndroidManifest me apne aap jod deta hai. Haath se kuch nahi karna.

**Abhi ke IDs:** App ID, Interstitial aur Banner asli hain. Sirf Rewarded abhi Google ka test ID hai.
AdMob me jab Rewarded ad unit bana lo, unke asli ID `www/ads-config.js` me badal do, phir `npx cap sync android` dobara chalao.

## Phone par test (APK)
```
npx cap open android
```
Android Studio khulega. USB se phone jodo (Developer options -> USB debugging ON), upar Run (hara triangle) dabao.
Test ads dikhne chahiye. Rewarded ad dekhne ke baad "Double coins" aur "Continue" kaam karne chahiye.

## Play Store ke liye AAB
Android Studio -> Build -> Generate Signed Bundle / APK -> Android App Bundle -> Next.
Naya keystore banao. **Keystore file aur password KHO MAT DENA** (Drive aur pen drive dono me rakho). Bina iske update nahi daal paoge.
Jo `.aab` file banegi wahi Play Console me upload hogi.

## Release se pehle
- `www/ads-config.js` me **TESTING:false** karo, `npx cap sync android` chalao, phir naya AAB banao.
- Apne hi ads par khud mat click karna, AdMob account band ho sakta hai.
- Play Console me app ko bacchon wali Families policy ke hisaab se bharo (Target audience, Data safety, Privacy policy).

## Dhyan do
- Plugin ke event naam aur settings is folder me meri yaad se likhe hain, maine unhe yahan compile ya test nahi kiya. Agar build me error aaye to @capacitor-community/admob ke README se naam mila lena. `www/ads-bridge.js` me hi badalna padega.
- Naye Capacitor/Android Studio ke version ke hisaab se kuch step thoda alag ho sakte hain.
